#ifndef FATORIAL_H
#define FATORIAL_H

unsigned fatorial(unsigned);

#endif
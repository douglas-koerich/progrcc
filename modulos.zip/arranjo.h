#ifndef ARRANJO_H
#define ARRANJO_H

#include "fatorial.h"

unsigned arranjo(unsigned, unsigned);

#endif
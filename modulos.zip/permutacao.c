#include "permutacao.h"

unsigned permutacao(unsigned x) {
	return fatorial(x);
}

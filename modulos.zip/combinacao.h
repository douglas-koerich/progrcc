#ifndef COMB_H
#define COMB_H

#include "fatorial.h"

unsigned combinacao(unsigned, unsigned);

#endif
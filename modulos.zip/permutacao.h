#ifndef PERM_H
#define PERM_H

#include "fatorial.h"

unsigned permutacao(unsigned);

#endif
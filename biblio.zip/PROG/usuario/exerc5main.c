#include <stdbool.h>
#include <stdio.h>
#include "exerc5mod.h"

int main() {
	int num;
	printf("Digite um numero: ");
	scanf("%d", &num);

	if (testaPalindromo(num)/* == true*/) {
		printf("O numero eh palindromo!\n");
	}
	else {
		printf("O numero nao eh palindromo!\n");
	}
	return 0;
}


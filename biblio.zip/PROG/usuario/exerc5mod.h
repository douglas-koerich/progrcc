// Prototipo da funcao
bool testaPalindromo(int);


#include <stdbool.h>
#include <stdio.h>

// Prototipo da funcao
bool testaPalindromo(int);

int main() {
	int num;
	printf("Digite um numero: ");
	scanf("%d", &num);

	if (testaPalindromo(num)/* == true*/) {
		printf("O numero eh palindromo!\n");
	}
	else {
		printf("O numero nao eh palindromo!\n");
	}
	return 0;
}

bool testaPalindromo(int N) {
	int palindromo = 0, quociente, resto, original = N;
	do {
		quociente = N / 10;
		resto = N % 10;
		palindromo = palindromo * 10 + resto;
		N = quociente;
	} while (N > 0);
	/*
	if (original == palindromo) {
		return true;
	}
	else {
		return false;
	}
	*/
	return original == palindromo;
}

